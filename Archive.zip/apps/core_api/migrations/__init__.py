"""Init core_api app

This module contains migrations for the core_api app.
"""

default_app_config = 'apps.core_api.apps.CoreApiConfig'
