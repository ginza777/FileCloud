default_app_config = 'apps.core_api.apps.CoreApiConfig'

