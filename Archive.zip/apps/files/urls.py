from django.urls import path
from . import views

app_name = 'files'

urlpatterns = [
    # Note: All API endpoints have been moved to core_api.api.web.urls
    # This file is kept for backward compatibility but is no longer used
]