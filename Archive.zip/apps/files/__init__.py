# Import tasks so they are registered with Celery
# Note: tasks are imported in celery.py to avoid Django app loading issues
