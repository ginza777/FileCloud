"""
Files Admin Panel Package
=========================

Bu paket files ilovasi uchun Django admin paneli konfiguratsiyalarini o'z ichiga oladi.

Fayllar:
- admin.py: Asosiy admin konfiguratsiyalari
"""

from .admin import *

