"""
Maintenance Commands Package
===========================

Bu paket tizimni tozalash, bakup va texnik xizmat ko'rsatish uchun komandalarni o'z ichiga oladi.
"""
